package com.example.humo.manager

class TestManager {
}