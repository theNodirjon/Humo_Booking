package com.example.humo.repo

import androidx.lifecycle.MutableLiveData

class DataRepository {

    val dataLiveData: MutableLiveData<String> = MutableLiveData()
}